var mongoose = require('mongoose');

var dbURI = 'mongodb://localhost/SRA';

mongoose.connect(dbURI);

require('./estudiantes');
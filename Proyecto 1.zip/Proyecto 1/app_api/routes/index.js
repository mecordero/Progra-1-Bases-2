var express = require('express');
var router = express.Router();
var ctrlUsers = require('../controllers/estudiantes');
//estudiantes
//router.post('/estudiantes', ctrlUsers.crearEstudiantes); 
router.get('/estudiantes/:carnet', ctrlUsers.leerUnEstudiante); 

module.exports = router;